function d=d(ff,nn)

ff_vec = (1+ff/2)*ones(1,2*nn);

d=1/prod(ff_vec);
